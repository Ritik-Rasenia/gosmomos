<?php $__env->startSection('title', 'Admin Dashboard — GOS MOMO'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-1">Welcome back, <?php echo e(Auth::user()->name); ?>! 👋</h4>
        <p class="text-muted mb-0">Here's your GOS MOMO platform overview for today.</p>
    </div>
    <div class="text-end">
        <span class="text-muted small"><?php echo e(now()->format('D, d M Y')); ?></span>
    </div>
</div>


<div class="row g-3 mb-4">
    <?php
    $stats = [
        ['icon'=>'bi-bag-check','label'=>'Total Orders','value'=>\App\Models\Order::count(),'color'=>'#FF7A00','sub'=>'All time'],
        ['icon'=>'bi-people','label'=>'Customers','value'=>\App\Models\User::whereHas('roles', fn($q)=>$q->where('slug','customer'))->count(),'color'=>'#FF7A00','sub'=>'Registered'],
        ['icon'=>'bi-briefcase','label'=>'Franchise Leads','value'=>\App\Models\FranchiseLead::count(),'color'=>'#E63946','sub'=>'Applications'],
        ['icon'=>'bi-currency-rupee','label'=>'Total Revenue','value'=>'₹'.number_format(\App\Models\Order::where('payment_status','paid')->sum('total')),'color'=>'#6f42c1','sub'=>'Paid orders'],
    ];
    ?>
    <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 col-xl-3">
        <div class="admin-card stat-card" style="border-left-color: <?php echo e($stat['color']); ?>">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="stat-title" style="color: <?php echo e($stat['color']); ?>"><?php echo e($stat['label']); ?></div>
                    <div class="stat-value" style="color: <?php echo e($stat['color']); ?>"><?php echo e($stat['value']); ?></div>
                    <small class="text-muted"><?php echo e($stat['sub']); ?></small>
                </div>
                <div style="width:50px; height:50px; border-radius:12px; background: <?php echo e($stat['color']); ?>20; display:flex; align-items:center; justify-content:center;">
                    <i class="bi <?php echo e($stat['icon']); ?> fs-4" style="color: <?php echo e($stat['color']); ?>"></i>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-4">
    
    <div class="col-lg-4">
        <div class="admin-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="bi bi-lightning-charge me-2 text-warning"></i>Quick Actions</h5>
            <div class="d-flex flex-column gap-2">
                <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-success rounded-2 text-start px-3">
                    <i class="bi bi-plus-circle me-2"></i> Add New Product
                </a>
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-outline-primary rounded-2 text-start px-3">
                    <i class="bi bi-cart-check me-2"></i> Manage Orders
                </a>
                <a href="<?php echo e(route('admin.franchise-leads.index')); ?>" class="btn btn-outline-warning rounded-2 text-start px-3">
                    <i class="bi bi-briefcase me-2"></i> Franchise Leads
                </a>
                <a href="<?php echo e(route('admin.event-leads.index')); ?>" class="btn btn-outline-danger rounded-2 text-start px-3">
                    <i class="bi bi-calendar-event me-2"></i> Event Inquiries
                </a>
                <a href="<?php echo e(route('home')); ?>" target="_blank" class="btn btn-outline-secondary rounded-2 text-start px-3">
                    <i class="bi bi-globe me-2"></i> View Website
                </a>
            </div>
        </div>
    </div>

    
    <div class="col-lg-8">
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0"><i class="bi bi-cart-check me-2 text-success"></i>Recent Orders</h5>
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-outline-success btn-sm rounded-pill px-3">View All</a>
            </div>
            <?php $recentOrders = \App\Models\Order::with(['user','items'])->latest()->take(5)->get(); ?>
            <?php if($recentOrders->count()): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr class="table-light">
                            <th class="small fw-semibold">Order #</th>
                            <th class="small fw-semibold">Customer</th>
                            <th class="small fw-semibold">Items</th>
                            <th class="small fw-semibold">Total</th>
                            <th class="small fw-semibold">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><span class="fw-bold text-success">#<?php echo e($order->order_number); ?></span></td>
                            <td><?php echo e($order->user->name); ?></td>
                            <td><?php echo e($order->items->count()); ?> item(s)</td>
                            <td class="fw-bold">₹<?php echo e(number_format($order->total, 0)); ?></td>
                            <td>
                                <?php
                                    $statusColors = ['placed'=>'primary','confirmed'=>'info','preparing'=>'warning','packed'=>'secondary','out_for_delivery'=>'dark','delivered'=>'success','cancelled'=>'danger'];
                                    $color = $statusColors[$order->status] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?php echo e($color); ?> rounded-pill"><?php echo e(ucfirst(str_replace('_',' ',$order->status))); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center text-muted py-4">
                <i class="bi bi-bag-x fs-1 mb-2 d-block opacity-25"></i>
                <p class="mb-0">No orders yet. Share the menu link to get started!</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="col-lg-4">
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0"><i class="bi bi-tags me-2 text-primary"></i>Categories</h5>
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline-primary btn-sm rounded-pill px-3">Manage</a>
            </div>
            <?php $cats = \App\Models\Category::withCount('products')->get(); ?>
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi <?php echo e($cat->icon ?? 'bi-circle'); ?> text-success"></i>
                    <span class="fw-semibold small"><?php echo e($cat->name); ?></span>
                </div>
                <span class="badge bg-success-subtle text-success"><?php echo e($cat->products_count); ?> items</span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="col-lg-8">
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0"><i class="bi bi-briefcase me-2 text-warning"></i>Latest Franchise Leads</h5>
                <a href="<?php echo e(route('admin.franchise-leads.index')); ?>" class="btn btn-outline-warning btn-sm rounded-pill px-3">View All</a>
            </div>
            <?php $leads = \App\Models\FranchiseLead::latest()->take(5)->get(); ?>
            <?php if($leads->count()): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead><tr class="table-light">
                        <th class="small fw-semibold">Name</th>
                        <th class="small fw-semibold">City</th>
                        <th class="small fw-semibold">Type</th>
                        <th class="small fw-semibold">Investment</th>
                        <th class="small fw-semibold">Status</th>
                    </tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><div class="fw-semibold"><?php echo e($lead->name); ?></div><div class="text-muted small"><?php echo e($lead->phone); ?></div></td>
                            <td><?php echo e($lead->city); ?></td>
                            <td><span class="badge bg-info-subtle text-info"><?php echo e(ucfirst($lead->franchise_type)); ?></span></td>
                            <td class="small"><?php echo e($lead->investment_budget); ?></td>
                            <td>
                                <?php $lc = ['new'=>'primary','contacted'=>'info','site_visit'=>'warning','approved'=>'success','rejected'=>'danger']; ?>
                                <span class="badge bg-<?php echo e($lc[$lead->status] ?? 'secondary'); ?>-subtle text-<?php echo e($lc[$lead->status] ?? 'secondary'); ?>"><?php echo e(ucfirst($lead->status)); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center text-muted py-4">
                <i class="bi bi-briefcase fs-1 mb-2 d-block opacity-25"></i>
                <p class="mb-0">No franchise leads yet. Share your franchise page!</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gosmomos\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>